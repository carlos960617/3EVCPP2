package Set.viernes1Abril;

public class PlanetaEnano extends CuerpoCeleste{

   public PlanetaEnano(String n, double PO){
       super(n, PO, TipoCuerpoCeleste.PLANETA_ENANO);
   }
}
