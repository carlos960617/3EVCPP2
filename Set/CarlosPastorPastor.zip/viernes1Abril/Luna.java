package Set.viernes1Abril;

public class Luna extends CuerpoCeleste{


    public Luna(String n, double PO){
        super(n, PO, TipoCuerpoCeleste.LUNA);
    }


}
