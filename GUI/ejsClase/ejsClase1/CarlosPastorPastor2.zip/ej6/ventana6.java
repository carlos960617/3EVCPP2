package GUI.ejsClase.ejsClase1.ej6;

import javax.swing.*;
import java.awt.*;

public class ventana6 extends JFrame {

    JButton jb1, jb2, jb3, jb4, jb5, jb6;

    public ventana6(String titulo, int locX, int locY, int sizeX, int sizeY){
        super(titulo);
        BorderLayout bl = new BorderLayout();
        jb1 = new JButton("Boton1");
        jb2 = new JButton("Boton2");
        jb3 = new JButton("Boton3");
        jb4 = new JButton("Boton4");
        jb5 = new JButton("Boton5");
        jb6 = new JButton("Boton6");

    }

    public static void main(String[] args) {

        ventana6 v6 = new ventana6("ventana6", 0,0,500,300);

    }
}
