package Generics.EjsClase.Dia2.Genericos2;

import Generics.EjsClase.Dia2.Genericos1.Pila;

public class PilaArray<T> {

    T[] lista;
    int insert;

    public PilaArray(int tam){
        lista = (T[])new Object[tam];
        insert = 0;
    }

    boolean estaVacia(){

        return insert == 0;
    }

    T extraer(){

        if(!estaVacia()){
            T valor = lista[0];
            if(lista.length == 1){
                lista = (T[]) new Object[0];
            }else{
                for(int i=1, j=0;i< lista.length;i++, j++){
                    lista[j] = lista[i];
                }
            }
            insert--;
            return valor;
        }else{
            return null;
        }
    }

    T primero(){

        return lista[0];
    }

    void añadir(T nuevoValor){

        int disponible = 0;
        int primeraDisponible = 0;

        for(int i=0;i< lista.length;i++){
            if(lista[i] == null && i==0){
                disponible++;
                primeraDisponible = i;
            }else if(lista[i] == null){
                disponible++;
            }
        }

        if(disponible > 0){
            lista[primeraDisponible] = nuevoValor;
            insert++;
    }else{
            System.out.println("No quedan huecos en la pila");}
    }

    @Override
    public String toString(){

        String array = " ";

        for(T x: lista){
            array += x+", ";
        }

        return array;
    }

}
