package LinkedList.EjClase.veintidosdemarzo;

import java.util.LinkedList;

public interface Saveable {


    LinkedList<String> write();

    void read(LinkedList<String> lista);


}
